`[.bma` <-
function (bmao, idx) 
{
    bmao$topmod <- bmao$topmod[idx]
    return(bmao)
}
