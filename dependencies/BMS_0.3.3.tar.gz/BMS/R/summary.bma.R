summary.bma <-
function (object, ...) 
{
    info.bma(object)
}
