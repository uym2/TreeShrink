deviance.zlm <-
function (object, ...) 
deviance.bma(object)
