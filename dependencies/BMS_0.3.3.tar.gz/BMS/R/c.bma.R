c.bma <-
function (..., recursive = FALSE) 
{
    combine_chains(...)
}
